package Orphan;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.PriorityQueue;

public class OrphanFundManagementGUI extends JFrame {
    JTextField donorIdField, nameField, amountField, timestampField;
    private JTable donorTable;
    private DefaultTableModel donorTableModel;

    private HashMapCustom<Integer, Donor> hashMap;
    private PriorityQueue<FundRequest> fundQueue;
    private double totalFunds;

    public OrphanFundManagementGUI() {
        hashMap = new HashMapCustom<>();
        fundQueue = new PriorityQueue<>((a, b) -> {
            // Priority: High < Medium < Low
            int priorityA = urgencyLevel(a.getUrgency());
            int priorityB = urgencyLevel(b.getUrgency());
            return priorityA - priorityB;
        });
        totalFunds = 0.0;

        setTitle("Orphan Fund Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Orphan Fund Management System", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        add(title, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        donorIdField = new JTextField();
        nameField = new JTextField();
        amountField = new JTextField();
        timestampField = new JTextField();

        inputPanel.add(new JLabel("Donor ID:"));
        inputPanel.add(donorIdField);
        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Amount Donated:"));
        inputPanel.add(amountField);
        inputPanel.add(new JLabel("Timestamp:"));
        inputPanel.add(timestampField);

        JButton addDonorBtn = new JButton("Add Donor");
        inputPanel.add(addDonorBtn);

        JButton displayTableBtn = new JButton("Display Donors (Tabular)");
        inputPanel.add(displayTableBtn);

        add(inputPanel, BorderLayout.WEST);

        donorTableModel = new DefaultTableModel(new String[]{"Donor ID", "Name", "Amount Donated", "Timestamp"}, 0);
        donorTable = new JTable(donorTableModel);
        JScrollPane tableScrollPane = new JScrollPane(donorTable);
        add(tableScrollPane, BorderLayout.CENTER);

        JPanel menuPanel = new JPanel(new GridLayout(11, 1, 5, 5));
        String[] buttons = {
                "1. Add Donor", "2. Display All Donors", "3. Retrieve Donor by ID",
                "4. Exit", "5. Add Fund Request", "6. Display Donors (Tabular)",
                "7. Allocate Fund", "8. View All Fund Requests", "9. View Total Funds",
                "10. View Allocation History", "11. View Transaction History"
        };

        for (String btnText : buttons) {
            JButton button = new JButton(btnText);
            menuPanel.add(button);
            button.addActionListener(e -> handleMenuClick(btnText));
        }

        add(menuPanel, BorderLayout.EAST);

        setVisible(true);

        addDonorBtn.addActionListener(e -> addDonor());
        displayTableBtn.addActionListener(e -> displayDonors());
    }

    private int urgencyLevel(String urgency) {
        return switch (urgency) {
            case "High" -> 1;
            case "Medium" -> 2;
            case "Low" -> 3;
            default -> 4;
        };
    }

    private void addDonor() {
        try {
            int id = Integer.parseInt(donorIdField.getText());
            String name = nameField.getText();
            double amount = Double.parseDouble(amountField.getText());
            String timestamp = timestampField.getText();

            Donor donor = new Donor(id, name, amount, timestamp);
            hashMap.put(id, donor);
            totalFunds += amount;

            JOptionPane.showMessageDialog(this, "Donor added successfully!");

            donorIdField.setText("");
            nameField.setText("");
            amountField.setText("");
            timestampField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check your entries.");
        }
    }

    private void displayDonors() {
        donorTableModel.setRowCount(0);
        for (Donor donor : hashMap.getAllValues()) {
            donorTableModel.addRow(new Object[]{
                    donor.donorId,
                    donor.name,
                    donor.amountDonated,
                    donor.timestamp
            });
        }
    }

    private void handleMenuClick(String btnText) {
        switch (btnText) {
            case "1. Add Donor":
                addDonor();
                break;

            case "2. Display All Donors":
            case "6. Display Donors (Tabular)":
                displayDonors();
                break;

            case "3. Retrieve Donor by ID":
                String idStr = JOptionPane.showInputDialog(this, "Enter Donor ID:");
                try {
                    int id = Integer.parseInt(idStr);
                    Donor donor = hashMap.get(id);
                    if (donor != null) {
                        String message = "Donor Details:\n" +
                                "ID: " + donor.donorId + "\n" +
                                "Name: " + donor.name + "\n" +
                                "Amount Donated: Rs " + donor.amountDonated + "\n" +
                                "Timestamp: " + donor.timestamp;
                        JOptionPane.showMessageDialog(this, message);
                    } else {
                        JOptionPane.showMessageDialog(this, "Donor not found with ID: " + id);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid ID entered.");
                }
                break;

            case "4. Exit":
                System.exit(0);
                break;

            case "5. Add Fund Request":
                try {
                    String reqIdStr = JOptionPane.showInputDialog(this, "Enter Fund Request ID:");
                    int reqId = Integer.parseInt(reqIdStr);

                    String amountStr = JOptionPane.showInputDialog(this, "Enter Requested Amount:");
                    double requestedAmount = Double.parseDouble(amountStr);

                    String urgency = (String) JOptionPane.showInputDialog(
                            this,
                            "Select Urgency Level:",
                            "Urgency",
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new String[]{"High", "Medium", "Low"},
                            "Medium");

                    String timestamp = JOptionPane.showInputDialog(this, "Enter Timestamp:");

                    FundRequest request = new FundRequest(reqId, requestedAmount, urgency, timestamp);
                    fundQueue.add(request);

                    JOptionPane.showMessageDialog(this, "Fund request added successfully!");

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Invalid input. Please try again.");
                }
                break;

            case "7. Allocate Fund":
                JOptionPane.showMessageDialog(this, "Allocating funds...");
                break;

            case "8. View All Fund Requests":
                if (fundQueue.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No fund requests available.");
                } else {
                    StringBuilder fundList = new StringBuilder("Fund Requests:\n");
                    for (FundRequest req : fundQueue) {
                        fundList.append("Request ID: ").append(req.getRequestId())
                                .append(", Amount: Rs ").append(req.getRequestedAmount())
                                .append(", Urgency: ").append(req.getUrgency())
                                .append(", Timestamp: ").append(req.getTimestamp())
                                .append("\n");
                    }
                    JOptionPane.showMessageDialog(this, fundList.toString());
                }
                break;

            case "9. View Total Funds":
                JOptionPane.showMessageDialog(this, "Total funds: Rs " + totalFunds);
                break;

            case "10. View Allocation History":
                JOptionPane.showMessageDialog(this, "Allocation history...");
                break;

            case "11. View Transaction History":
                JOptionPane.showMessageDialog(this, "Transaction history...");
                break;

            default:
                break;
        }
    }

    public class FundRequest {
        private int requestId;
        private double requestedAmount;
        private String urgency;
        private String timestamp;

        public FundRequest(int requestId, double requestedAmount, String urgency, String timestamp) {
            this.requestId = requestId;
            this.requestedAmount = requestedAmount;
            this.urgency = urgency;
            this.timestamp = timestamp;
        }

        public int getRequestId() {
            return requestId;
        }

        public void setRequestId(int requestId) {
            this.requestId = requestId;
        }

        public double getRequestedAmount() {
            return requestedAmount;
        }

        public void setRequestedAmount(double requestedAmount) {
            this.requestedAmount = requestedAmount;
        }

        public String getUrgency() {
            return urgency;
        }

        public void setUrgency(String urgency) {
            this.urgency = urgency;
        }

        public String getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(String timestamp) {
            this.timestamp = timestamp;
        }
    }

    public static void main(String[] args) {
        new OrphanFundManagementGUI();
    }
}