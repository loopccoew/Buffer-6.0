package Orphan;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.PriorityQueue;

public class DemoFrame {
    private JFrame frame;
    private JPanel panel;
    private JTextField donorNameField, donorIdField, amountField, timestampField;
    private JButton addDonorButton, displayDonorsButton;
    private JTable donorTable;
    private DefaultTableModel donorTableModel;

    // Custom data structures
    private HashMapCustom<Integer, Donor> donorMap;
    private PriorityQueue<FundRequest> fundQueue;
    private double totalFunds;

    public DemoFrame() {
        // Initialize
        donorMap = new HashMapCustom<>();
        fundQueue = new PriorityQueue<>();
        totalFunds = 0.0;

        // Setup Frame
        frame = new JFrame("Orphan Fund Management");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel for form inputs
        panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));

        // Labels and Fields
        JLabel donorIdLabel = new JLabel("Donor ID:");
        donorIdField = new JTextField();

        JLabel donorNameLabel = new JLabel("Donor Name:");
        donorNameField = new JTextField();

        JLabel amountLabel = new JLabel("Amount Donated:");
        amountField = new JTextField();

        JLabel timestampLabel = new JLabel("Timestamp:");
        timestampField = new JTextField();

        // Buttons
        addDonorButton = new JButton("Add Donor");
        displayDonorsButton = new JButton("Display Donors");

        // Donor Table
        donorTableModel = new DefaultTableModel(new String[] { "Donor ID", "Name", "Amount Donated", "Timestamp" }, 0);
        donorTable = new JTable(donorTableModel);
        JScrollPane tableScrollPane = new JScrollPane(donorTable);

        // Add components to panel
        panel.add(donorIdLabel);
        panel.add(donorIdField);
        panel.add(donorNameLabel);
        panel.add(donorNameField);
        panel.add(amountLabel);
        panel.add(amountField);
        panel.add(timestampLabel);
        panel.add(timestampField);
        panel.add(addDonorButton);
        panel.add(displayDonorsButton);

        // Add to frame
        frame.getContentPane().add(BorderLayout.NORTH, panel);
        frame.getContentPane().add(BorderLayout.CENTER, tableScrollPane);
        frame.setVisible(true);

        // Action Listeners
        addDonorButton.addActionListener(e -> addDonor());
        displayDonorsButton.addActionListener(e -> displayDonors());
    }

    private void addDonor() {
        try {
            int id = Integer.parseInt(donorIdField.getText().trim());
            String name = donorNameField.getText().trim();
            double amount = Double.parseDouble(amountField.getText().trim());
            String timestamp = timestampField.getText().trim();

            if (name.isEmpty() || timestamp.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.");
                return;
            }

            Donor donor = new Donor(id, name, amount, timestamp);
            donorMap.put(id, donor);
            totalFunds += amount;

            JOptionPane.showMessageDialog(frame, "✅ Donor added successfully!");

            // Clear fields
            donorIdField.setText("");
            donorNameField.setText("");
            amountField.setText("");
            timestampField.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "❌ Invalid number format. Please check your entries.");
        }
    }

    private void displayDonors() {
        donorTableModel.setRowCount(0); // Clear previous data
        for (Donor donor : donorMap.getAllValues()) {
            donorTableModel.addRow(new Object[] {
                    donor.donorId,
                    donor.name,
                    donor.amountDonated,
                    donor.timestamp
            });
        }
    }

    public static void main(String[] args) {
        new DemoFrame();
    }
}
