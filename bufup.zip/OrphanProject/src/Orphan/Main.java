package Orphan;

import java.util.*;

// Transaction class (Doubly Linked List Node)
class Transaction {
    int transactionId;
    double amount;
    String sender;
    String receiver;
    String timestamp;
    Transaction prev;
    Transaction next;

    public Transaction(int transactionId, double amount, String sender, String receiver, String timestamp) {
        this.transactionId = transactionId;
        this.amount = amount;
        this.sender = sender;
        this.receiver = receiver;
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "TxnID: " + transactionId + ", Amount: ₹" + amount + ", From: " + sender + ", To: " + receiver + ", Time: " + timestamp;
    }
}

// Doubly Linked List for transaction history
class TransactionHistory {
    private Transaction head;
    private Transaction tail;
    private int txnCounter = 1;

    public void insertTransaction(double amount, String sender, String receiver, String timestamp) {
        Transaction newTxn = new Transaction(txnCounter++, amount, sender, receiver, timestamp);
        if (head == null) {
            head = tail = newTxn;
        } else {
            tail.next = newTxn;
            newTxn.prev = tail;
            tail = newTxn;
        }
    }

    public void displayAllTransactions() {
        if (head == null) {
            System.out.println("⚠ No transactions to display.");
            return;
        }

        System.out.println("\n🔁 Transaction History:");
        Transaction curr = head;
        while (curr != null) {
            System.out.println(curr);
            curr = curr.next;
        }
    }
}

// Donor class
class Donor {
    int donorId;
    String name;
    double amountDonated;
    String timestamp;

    public Donor(int donorId, String name, double amountDonated, String timestamp) {
        this.donorId = donorId;
        this.name = name;
        this.amountDonated = amountDonated;
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "Donor ID: " + donorId + ", Name: " + name + ", Amount Donated: ₹" + amountDonated + ", Timestamp: " + timestamp;
    }
}

// Custom HashMap class
class HashMapCustom<K, V> {
    private class Node {
        K key;
        V value;
        public Node(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    private int n;
    private int N;
    private LinkedList<Node>[] buckets;

    @SuppressWarnings("unchecked")
    public HashMapCustom() {
        this.N = 4;
        this.buckets = new LinkedList[N];
        for (int i = 0; i < N; i++) {
            this.buckets[i] = new LinkedList<>();
        }
    }

    private int hashFunction(K key) {
        int hashCode = key.hashCode();
        return Math.abs(hashCode) % N;
    }

    private int searchInBucket(K key, int bi) {
        LinkedList<Node> bucket = buckets[bi];
        for (int i = 0; i < bucket.size(); i++) {
            if (bucket.get(i).key.equals(key)) {
                return i;
            }
        }
        return -1;
    }

    @SuppressWarnings("unchecked")
    private void rehash() {
        LinkedList<Node>[] oldBuckets = buckets;
        N = N * 2;
        buckets = new LinkedList[N];
        for (int i = 0; i < N; i++) {
            buckets[i] = new LinkedList<>();
        }

        n = 0;
        for (LinkedList<Node> bucket : oldBuckets) {
            for (Node node : bucket) {
                put(node.key, node.value);
            }
        }
    }

    public void put(K key, V value) {
        int bi = hashFunction(key);
        int di = searchInBucket(key, bi);

        if (di != -1) {
            buckets[bi].get(di).value = value;
        } else {
            buckets[bi].add(new Node(key, value));
            n++;
        }

        double lambda = (double) n / N;
        if (lambda > 2.0) {
            rehash();
        }
    }

    public V get(K key) {
        int bi = hashFunction(key);
        int di = searchInBucket(key, bi);

        if (di != -1) {
            return buckets[bi].get(di).value;
        }
        return null;
    }

    public Collection<V> getAllValues() {
        List<V> allValues = new ArrayList<>();
        for (LinkedList<Node> bucket : buckets) {
            for (Node node : bucket) {
                allValues.add(node.value);
            }
        }
        return allValues;
    }

    public void printHashMap() {
        for (int i = 0; i < buckets.length; i++) {
            if (!buckets[i].isEmpty()) {
                for (Node node : buckets[i]) {
                    System.out.println("[Key: " + node.key + ", Value: " + node.value.toString() + "]");
                }
            }
        }
    }
}

// FundRequest class (for Priority Queue)
class FundRequest implements Comparable<FundRequest> {
    String requesterName;
    String purpose;
    double amount;
    int priority;

    public FundRequest(String requesterName, String purpose, double amount) {
        this.requesterName = requesterName;
        this.purpose = purpose;
        this.amount = amount;
        this.priority = getPriorityLevel(purpose);
    }

    private int getPriorityLevel(String purpose) {
        switch (purpose.toLowerCase()) {
            case "medical": return 1;
            case "education": return 2;
            case "food & shelter": return 3;
            default: return 4;
        }
    }

    @Override
    public int compareTo(FundRequest other) {
        return Integer.compare(this.priority, other.priority);
    }

    @Override
    public String toString() {
        return "Requester: " + requesterName + ", Purpose: " + purpose +
                ", Amount: ₹" + amount + ", Priority: " + priority;
    }
}

// Main Class
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashMapCustom<Integer, Donor> hashMap = new HashMapCustom<>();
        PriorityQueue<FundRequest> fundQueue = new PriorityQueue<>();
        List<FundRequest> allocationHistory = new ArrayList<>();
        TransactionHistory transactionHistory = new TransactionHistory();

        double totalFunds = 0;
        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Add Donor");
            System.out.println("2. Display All Donors");
            System.out.println("3. Retrieve Donor by ID");
            System.out.println("4. Exit");
            System.out.println("5. Add Fund Request");
            System.out.println("6. Display Donors (Tabular)");
            System.out.println("7. Allocate Fund");
            System.out.println("8. View All Fund Requests");
            System.out.println("9. View Total Funds");
            System.out.println("10. View Allocation History");
            System.out.println("11. View Transaction History");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1: {
                    System.out.print("Enter Donor ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Donor Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Amount Donated: ₹");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Enter Timestamp: ");
                    String timestamp = scanner.nextLine();

                    Donor donor = new Donor(id, name, amount, timestamp);
                    hashMap.put(id, donor);
                    totalFunds += amount;
                    System.out.println("✅ Donor added!");
                    break;
                }

                case 2:
                    hashMap.printHashMap();
                    break;

                case 3:
                    System.out.print("Enter Donor ID: ");
                    int did = scanner.nextInt();
                    Donor d = hashMap.get(did);
                    System.out.println((d != null) ? d : "❌ Donor not found.");
                    break;

                case 4:
                    System.out.println("Goodbye!");
                    break;

                case 5:
                    System.out.print("Enter Requester Name: ");
                    String rName = scanner.nextLine();
                    System.out.print("Enter Purpose: (Medical, Education, Food & Shelter, Orphan Support, Emergency, Other) ");
                    String rPurpose = scanner.nextLine();
                    System.out.print("Enter Amount Required: ₹");
                    double rAmt = scanner.nextDouble();
                    scanner.nextLine();
                    fundQueue.add(new FundRequest(rName, rPurpose, rAmt));
                    System.out.println("✅ Fund request added!");
                    break;

                case 6:
                    System.out.println("\n┌──────────┬────────────────────┬────────────────────┬────────────────────┐");
                    System.out.printf("│ %-8s │ %-18s │ %-18s │ %-18s │\n", "Donor ID", "Name", "Amount Donated", "Timestamp");
                    System.out.println("├──────────┼────────────────────┼────────────────────┼────────────────────┤");

                    for (Donor donorRow : hashMap.getAllValues()) {
                        System.out.printf("│ %-8d │ %-18s │ ₹%-17.2f │ %-18s │\n",
                                donorRow.donorId, donorRow.name, donorRow.amountDonated, donorRow.timestamp);
                    }

                    System.out.println("└──────────┴────────────────────┴────────────────────┴────────────────────┘");
                    break;

                case 7:
                    if (!fundQueue.isEmpty()) {
                        FundRequest req = fundQueue.peek();
                        if (req.amount <= totalFunds) {
                            fundQueue.poll();
                            totalFunds -= req.amount;
                            allocationHistory.add(req);

                            String now = new Date().toString();
                            transactionHistory.insertTransaction(req.amount, "OrphanFund", req.requesterName, now);
                            System.out.println("✅ Fund Allocated:\n" + req);
                        } else {
                            System.out.println("❌ Insufficient Funds.");
                        }
                    } else {
                        System.out.println("⚠ No fund requests.");
                    }
                    break;

                case 8:
                    if (!fundQueue.isEmpty()) {
                        PriorityQueue<FundRequest> temp = new PriorityQueue<>(fundQueue);

                        System.out.println("\n📋 Pending Fund Requests (Priority Order):");
                        System.out.printf("%-5s %-20s %-20s %-15s %-10s\n", "No.", "Requester", "Purpose", "Amount", "Priority");
                        System.out.println("-------------------------------------------------------------------------------");

                        int count = 1;
                        while (!temp.isEmpty()) {
                            FundRequest fr = temp.poll();
                            System.out.printf("%-5d %-20s %-20s ₹%-14.2f %-10d\n",
                                    count++, fr.requesterName, fr.purpose, fr.amount, fr.priority);
                        }
                    } else {
                        System.out.println("⚠ No fund requests.");
                    }
                    break;

                case 9:
                    System.out.printf("💰 Total Funds: ₹%.2f\n", totalFunds);
                    break;

                case 10:
                    if (!allocationHistory.isEmpty()) {
                        System.out.println("\n📋 Fund Allocation History:");
                        System.out.println("┌────────────────────┬────────────────────┬────────────────────┬");
                        System.out.printf("│ %-18s │ %-18s │ %-18s │\n", "Requester", "Purpose", "Amount");
                        System.out.println("├────────────────────┼────────────────────┼────────────────────┤");
                        for (FundRequest fr : allocationHistory) {
                            System.out.printf("│ %-18s │ %-18s │ ₹%-17.2f │\n", fr.requesterName, fr.purpose, fr.amount);
                        }
                    } else {
                        System.out.println("⚠ No allocations yet.");
                    }
                    break;

                case 11:
                    transactionHistory.displayAllTransactions();
                    break;

                default:
                    System.out.println("❌ Invalid choice! Please try again.");
                    break;
            }
        } while (choice != 4);

        scanner.close();
    }
}