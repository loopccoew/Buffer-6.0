package com.example.piggybank;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddGoalActivity extends AppCompatActivity {

    private EditText nameInput, targetInput, priority;
    private Button btnAddGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_goal);

        nameInput = findViewById(R.id.inputGoalName);
        targetInput = findViewById(R.id.inputTargetAmount);
        priority = findViewById(R.id.inputPriority);
        btnAddGoal = findViewById(R.id.btnCreateGoal);

        btnAddGoal.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            int targetAmount = Integer.parseInt(targetInput.getText().toString().trim());

            if (name.isEmpty() || targetInput.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

//            try {
//                double targetAmount = Double.parseDouble(targetStr);
//                Goal newGoal = new Goal(name, targetAmount);
//                PiggyBankApp.goalManager.addGoal(newGoal);
//
//                Toast.makeText(this, "🎯 Goal Added!", Toast.LENGTH_SHORT).show();
//                finish(); // Go back to ViewGoalsActivity
//            } catch (NumberFormatException e) {
//                Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
//            }

            String priorityStr = priority.getText().toString().trim();
            if (priorityStr.isEmpty()) {
                Toast.makeText(this, "Please enter a priority", Toast.LENGTH_SHORT).show();
                return;
            }

            int priority = Integer.parseInt(priorityStr);
            if (priority < 1 || priority > 5) {
                Toast.makeText(this, "Priority must be between 1 and 5", Toast.LENGTH_SHORT).show();
                return;
            }

            Goal newGoal = new Goal(name, targetAmount, priority);
            PiggyBankApp.goalManager.addGoal(name, targetAmount, priority);
            finish();
        });
    }
}

