package com.example.piggybank;

import android.app.Application;

public class PiggyBankApp extends Application {
    public static GoalManager goalManager;

    @Override
    public void onCreate() {
        super.onCreate();
        goalManager = new GoalManager(); // ✅ shared for whole app
    }
}
