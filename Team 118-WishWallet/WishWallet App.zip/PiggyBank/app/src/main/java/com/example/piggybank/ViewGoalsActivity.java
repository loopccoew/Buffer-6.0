package com.example.piggybank;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class ViewGoalsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private GoalAdapter adapter;
    private FloatingActionButton fabAddGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_goals);

        recyclerView = findViewById(R.id.recyclerGoals);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new GoalAdapter(PiggyBankApp.goalManager.getAllGoals());
        recyclerView.setAdapter(adapter);

        fabAddGoal = findViewById(R.id.fabAddGoal);
        fabAddGoal.setOnClickListener(v -> {
            Intent intent = new Intent(ViewGoalsActivity.this, AddGoalActivity.class);
            startActivity(intent);
        });
    }
}
