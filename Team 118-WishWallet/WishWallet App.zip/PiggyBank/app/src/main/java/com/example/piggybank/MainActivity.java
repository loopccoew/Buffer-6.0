package com.example.piggybank;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    static GoalManager goalManager = PiggyBankApp.goalManager;
    // Ideally shared with other activities

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView welcomeText = findViewById(R.id.txtWelcome);
        Button btnAddGoal = findViewById(R.id.btnAddGoal);
        Button btnAddMoney = findViewById(R.id.btnAddMoney);
        Button btnViewGoals = findViewById(R.id.btnViewGoals);

        // Welcome message
        welcomeText.setText("What would you like to do today?");

//        if (goalManager.getAllGoals().isEmpty()) {
//            goalManager.addGoal("Buy Laptop", 30000, 1);
//            goalManager.addGoal("Trip to Goa", 15000, 2);
//            goalManager.getAllGoals().get(0).getsavedAmount = 5000;
//            goalManager.getAllGoals().get(1).savedAmount = 2000;
//        }

        // Navigation choices
        btnAddGoal.setOnClickListener(v -> {
            startActivity(new Intent(this, AddGoalActivity.class));
        });

        btnAddMoney.setOnClickListener(v -> {
            startActivity(new Intent(this, AddMoneyActivity.class));
        });

        btnViewGoals.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ViewGoalsActivity.class);
            startActivity(intent);
        });
    }
    private void showGoals() {
        StringBuilder goalList = new StringBuilder();
        for (Goal g : goalManager.getAllGoals()) {
            goalList.append("• ").append(g.getName())
                    .append(": ₹").append(g.getSavedAmount())
                    .append("/₹").append(g.getTargetAmount()).append("\n");
        }
        Toast.makeText(this, goalList.toString(), Toast.LENGTH_LONG).show();
    }
}