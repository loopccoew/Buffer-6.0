package com.example.piggybank;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
//import GoalManager.Goal;
import java.util.List;

public class GoalAdapter extends RecyclerView.Adapter<GoalAdapter.GoalViewHolder> {

    private List<Goal> goalList;

    public GoalAdapter(List<Goal> goalList) {
        this.goalList = goalList;
    }

    @NonNull
    @Override
    public GoalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_goal_card, parent, false);
        return new GoalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GoalViewHolder holder, int position) {
        Goal goal = goalList.get(position);
        holder.goalName.setText(goal.getName());

        double saved = goal.getSavedAmount();
        double target = goal.getTargetAmount();
        double percent = (target == 0) ? 0 : (saved / target) * 100;

        holder.amountSaved.setText(
                String.format("₹%.2f / ₹%.2f", saved, target)
        );
        holder.progressBar.setProgress((int) percent);
    }

    @Override
    public int getItemCount() {
        return goalList.size();
    }

    static class GoalViewHolder extends RecyclerView.ViewHolder {
        TextView goalName, amountSaved;
        ProgressBar progressBar;

        public GoalViewHolder(@NonNull View itemView) {
            super(itemView);
            goalName = itemView.findViewById(R.id.goalTitle);
            amountSaved = itemView.findViewById(R.id.goalAmount);
            progressBar = itemView.findViewById(R.id.goalProgress);
        }
    }
}
