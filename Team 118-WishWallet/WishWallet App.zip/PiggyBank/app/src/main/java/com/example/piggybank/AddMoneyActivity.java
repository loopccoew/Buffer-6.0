package com.example.piggybank;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;

public class AddMoneyActivity extends AppCompatActivity {

    GoalManager goalManager = PiggyBankApp.goalManager;
    // Normally shared instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_money);

        EditText edtAmount = findViewById(R.id.edtAddAmount);
        Button btnAdd = findViewById(R.id.btnAddMoney);

        btnAdd.setOnClickListener(v -> {
            int amt = Integer.parseInt(edtAmount.getText().toString());
            goalManager.addMoney(amt, getApplicationContext());
            Toast.makeText(this, "Money Added!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
