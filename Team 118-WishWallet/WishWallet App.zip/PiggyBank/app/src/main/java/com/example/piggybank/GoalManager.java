package com.example.piggybank;
//import com.example.piggybank.Goal;

import android.content.Context;
import android.widget.Toast;

import java.util.*;

public class GoalManager {

    // HashMap to store goals by name
    private final HashMap<String, Goal> goalsMap = new HashMap<>();

    // Comparator for prioritizing goals (DSA: Priority Queue)
    private final Comparator<Goal> goalComparator = (g1, g2) -> {
        if (g1.getPriority() != g2.getPriority())
            return Integer.compare(g1.getPriority(), g2.getPriority()); // smaller number = higher priority
        return Integer.compare(g1.getRemainingAmount(), g2.getRemainingAmount()); // then sort by needed amount
    };

    // Add a new goal
    public void addGoal(String name, int targetAmount, int priority) {
        Goal goal = new Goal(name, targetAmount, priority);
        goalsMap.put(name, goal);
    }

    // Add money and distribute it smartly using a greedy + priority algorithm
//    public void addMoney(int amount) {
//        // Use a priority queue to sort goals
//        PriorityQueue<Goal> queue = new PriorityQueue<>(goalComparator);
//        queue.addAll(goalsMap.values());
//
//
//        while (amount > 0 && !queue.isEmpty()) {
//            Goal goal = queue.poll();
//            double savedAmount = goal.getSavedAmount();
//            int remaining = goal.getRemainingAmount();
//            if (remaining > 0) {
//                int toAdd = Math.min(amount, goal.getRemainingAmount());
//                goal.addAmount(toAdd); // this should update the internal saved amount
//                amount -= toAdd;
//
//            }
//        }
//    }

    public void addMoney(int amount, Context context) {
        // Use a priority queue to sort goals
        PriorityQueue<Goal> queue = new PriorityQueue<>(goalComparator);
        queue.addAll(goalsMap.values());

        List<String> completedGoals = new ArrayList<>();

        while (amount > 0 && !queue.isEmpty()) {
            Goal goal = queue.poll();
            int remaining = goal.getRemainingAmount();

            if (remaining > 0) {
                int toAdd = Math.min(amount, remaining);
                goal.addAmount(toAdd); // update saved amount
                amount -= toAdd;

                // Check if goal is completed after adding money
                if (goal.getRemainingAmount() <= 0) {
                    completedGoals.add(goal.getName());
                }
            }
        }

        // Remove completed goals from map
        goalsMap.values().removeIf(goal -> goal.getRemainingAmount() <= 0);

        // Show toast for completed goals
        for (String goalName : completedGoals) {
            Toast.makeText(context, "Goal completed: " + goalName, Toast.LENGTH_SHORT).show();
        }
    }


    // Return list of all goals
    public List<Goal> getAllGoals() {
        return new ArrayList<>(goalsMap.values());
    }

    // For displaying or debugging
    public String getSummary() {
        StringBuilder sb = new StringBuilder();
        for (Goal goal : goalsMap.values()) {
            sb.append(goal.getName())
                    .append(": ₹")
                    .append(goal.getSavedAmount())
                    .append(" / ₹")
                    .append(goal.getTargetAmount())
                    .append("\n");
        }
        return sb.toString();
    }
}

