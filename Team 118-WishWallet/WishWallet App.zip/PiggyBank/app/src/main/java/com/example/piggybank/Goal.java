package com.example.piggybank;

public class Goal implements Comparable<Goal> {
    public String name;
    public double targetAmount;
    public double savedAmount;
    public int priority; // 1 = highest, 5 = lowest

    public Goal(String name, double targetAmount, int priority) {
        this.name = name;
        this.targetAmount = targetAmount;
        this.savedAmount = 0;
        this.priority = priority;
    }

    public String getName() {
        return name;
    }

    public double getTargetAmount() {
        return targetAmount;
    }

    public double getSavedAmount() {
        return savedAmount;
    }

    public int getPriority() {
        return priority;
    }

    public void addAmount(double amount) {
        this.savedAmount += amount;
    }

    public double getProgressPercent() {
        if (targetAmount == 0) return 0;
        return (savedAmount / targetAmount) * 100;
    }

    public int getRemainingAmount() {
        return (int)(targetAmount - savedAmount);
    }


    @Override
    public int compareTo(Goal other) {
        return Integer.compare(this.priority, other.priority); // Lower value = higher priority
    }
}
