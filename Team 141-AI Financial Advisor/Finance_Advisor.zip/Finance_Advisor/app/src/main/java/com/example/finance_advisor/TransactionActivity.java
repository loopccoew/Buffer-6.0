package com.example.finance_advisor;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class TransactionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TransactionAdapter adapter;
    private ArrayList<Transaction> transactionList; // Ensure this is ArrayList

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        recyclerView = findViewById(R.id.recyclerViewTransactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Fetch transactions from DB (ensure it's ArrayList)
        DBHelper dbHelper = new DBHelper(this);
        transactionList = dbHelper.getAllTransactions(); // This should return an ArrayList<Transaction>

        // Set adapter
        adapter = new TransactionAdapter(this, transactionList, dbHelper);
        recyclerView.setAdapter(adapter);
    }
}
