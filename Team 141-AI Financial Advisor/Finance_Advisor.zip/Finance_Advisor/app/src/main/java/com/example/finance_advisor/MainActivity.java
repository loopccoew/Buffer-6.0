package com.example.finance_advisor;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView welcomeText, walletBalance;
    Button addTransactionBtn, viewTransactionsBtn, undoTransactionBtn, addPaymentBtn;
    Button viewPaymentsBtn, addMoneyBtn, viewReportBtn, manageTransactionBtn, exitBtn, viewCategoryTransactionsBtn;
    EditText categoryInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        welcomeText = findViewById(R.id.welcomeText);
        walletBalance = findViewById(R.id.walletBalance);
        addTransactionBtn = findViewById(R.id.addTransactionBtn);
        viewTransactionsBtn = findViewById(R.id.viewTransactionsBtn);
        undoTransactionBtn = findViewById(R.id.undoTransactionBtn);
        addPaymentBtn = findViewById(R.id.addPaymentBtn);
        viewPaymentsBtn = findViewById(R.id.viewPaymentsBtn);
        addMoneyBtn = findViewById(R.id.addMoneyBtn);
        viewReportBtn = findViewById(R.id.viewReportBtn);
        manageTransactionBtn = findViewById(R.id.manageTransactionBtn);
        exitBtn = findViewById(R.id.exitBtn);
        viewCategoryTransactionsBtn = findViewById(R.id.viewCategoryTransactionsBtn);
        categoryInput = findViewById(R.id.categoryInput);

        // Dummy welcome message & wallet balance (You can fetch this from the database later)
        welcomeText.setText("Welcome, User!");
        walletBalance.setText("Wallet: ₹5000.00");

        // OnClickListener for Add Transaction Button
        addTransactionBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddTransactionActivity.class);
            startActivity(intent);
        });

        // OnClickListener for View Transactions Button
        viewTransactionsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ViewTransactionsActivity.class);
            startActivity(intent);
        });

        // OnClickListener for Undo Transaction Button
        undoTransactionBtn.setOnClickListener(v -> {
            undoLastTransaction();
        });

        // OnClickListener for Add Payment Button
        addPaymentBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddPaymentActivity.class);
            startActivity(intent);
        });

        // OnClickListener for View Payments Button
        viewPaymentsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ViewPaymentsActivity.class);
            startActivity(intent);
        });

        // OnClickListener for Add Money to Wallet Button
        addMoneyBtn.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Add Money Clicked", Toast.LENGTH_SHORT).show();
        });

        // OnClickListener for View Category Report Button
        viewReportBtn.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "View Report Clicked", Toast.LENGTH_SHORT).show();
        });

        // OnClickListener for Edit/Delete Transaction Button
        manageTransactionBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ManageTransactionsActivity.class);
            startActivity(intent);
        });

        // OnClickListener for Exit Button
        exitBtn.setOnClickListener(v -> finish()); // Close the app

        // OnClickListener for View Category Transactions Button
        viewCategoryTransactionsBtn.setOnClickListener(v -> {
            String category = categoryInput.getText().toString().trim();

            if (!category.isEmpty()) {
                Intent intent = new Intent(MainActivity.this, CategoryTransactionsActivity.class);
                intent.putExtra("category", category);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Please enter a category", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void undoLastTransaction() {
        // Assuming you have a method in your DBHelper class to undo the last transaction
        DBHelper dbHelper = new DBHelper(this);
        boolean success = dbHelper.deleteLastTransaction(); // Modify according to your DBHelper logic

        if (success) {
            Toast.makeText(MainActivity.this, "Last transaction undone", Toast.LENGTH_SHORT).show();
            // You can optionally refresh the UI or navigate to another screen after undoing the transaction.
        } else {
            Toast.makeText(MainActivity.this, "No transaction to undo", Toast.LENGTH_SHORT).show();
        }
    }
}
