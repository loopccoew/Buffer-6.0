package com.example.finance_advisor;

import android.content.ContentValues;
import android.content.Context;
import java.util.ArrayList;
import java.util.List;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "FinanceDB";
    private static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create user_info table
        db.execSQL("CREATE TABLE IF NOT EXISTS user_info (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "income REAL, " +
                "profession TEXT, " +
                "area TEXT)");

        // Create transactions table
        db.execSQL("CREATE TABLE IF NOT EXISTS transactions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "category TEXT, " +
                "amount REAL, " +
                "timestamp TEXT)");

        // Create payments table
        db.execSQL("CREATE TABLE IF NOT EXISTS payments (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "category TEXT, " +
                "amount REAL, " +
                "due_date TEXT)");

        // Create wallet table (if needed, depending on your logic)
        db.execSQL("CREATE TABLE IF NOT EXISTS wallet (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "balance REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS user_info");
        db.execSQL("DROP TABLE IF EXISTS transactions");
        db.execSQL("DROP TABLE IF EXISTS payments");
        db.execSQL("DROP TABLE IF EXISTS wallet");
        onCreate(db);
    }

    // Save user using User object
    public void saveUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", user.getName());
        values.put("income", user.getIncome());
        values.put("profession", user.getProfession());
        values.put("area", user.getArea());
        db.insert("user_info", null, values);
        db.close();
    }

    // Delete last transaction
    public boolean deleteLastTransaction() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM transactions ORDER BY id DESC LIMIT 1", null);
        if (cursor.moveToFirst()) {
            int lastId = cursor.getInt(0);
            db.delete("transactions", "id = ?", new String[]{String.valueOf(lastId)});
            cursor.close();
            return true;
        }
        cursor.close();
        return false;
    }

    // Insert payment
    public boolean insertPayment(String category, double amount, String dueDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("category", category);
        values.put("amount", amount);
        values.put("due_date", dueDate);

        long result = db.insert("payments", null, values);
        db.close();
        return result != -1;
    }
    public ArrayList<Payment> getAllPayments() {
        ArrayList<Payment> paymentsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM payments", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
                double amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount"));
                String dueDate = cursor.getString(cursor.getColumnIndexOrThrow("due_date"));
                paymentsList.add(new Payment(id, category, amount, dueDate));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return paymentsList;
    }

    // Insert user manually
    public boolean insertUser(String name, double income, String profession, String area) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("income", income);
        values.put("profession", profession);
        values.put("area", area);
        long result = db.insert("user_info", null, values);
        db.close();
        return result != -1;
    }

    // Insert transaction
    public boolean insertTransaction(String category, double amount, String timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("category", category);
        values.put("amount", amount);
        values.put("timestamp", timestamp);
        long result = db.insert("transactions", null, values);
        db.close();
        return result != -1;
    }

    // Get all transactions
    public ArrayList<Transaction> getAllTransactions() {
        ArrayList<Transaction> transactions = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM transactions", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
                double amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount"));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));
                transactions.add(new Transaction(id, category, amount, timestamp));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return transactions;
    }

    // Get user info
    public User getUserInfo() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user_info LIMIT 1", null);

        if (cursor != null && cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            double income = cursor.getDouble(cursor.getColumnIndexOrThrow("income"));
            String profession = cursor.getString(cursor.getColumnIndexOrThrow("profession"));
            String area = cursor.getString(cursor.getColumnIndexOrThrow("area"));
            cursor.close();
            db.close();
            return new User(name, income, profession, area);
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }

    // Get transactions by category
    public ArrayList<Transaction> getTransactionsByCategory(String category) {
        ArrayList<Transaction> transactions = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM transactions WHERE category = ?", new String[]{category});

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String cat = cursor.getString(cursor.getColumnIndexOrThrow("category"));
                double amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount"));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));
                transactions.add(new Transaction(id, cat, amount, timestamp));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return transactions;
    }

    // Delete transaction by ID
    public boolean deleteTransaction(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("transactions", "id=?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    // Update user info
    public boolean updateUser(int id, String name, double income, String profession, String area) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("income", income);
        values.put("profession", profession);
        values.put("area", area);
        int result = db.update("user_info", values, "id=?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    // Undo last transaction
    public Transaction undoLastTransaction() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM transactions ORDER BY id DESC LIMIT 1", null);
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String category = cursor.getString(cursor.getColumnIndexOrThrow("category"));
            double amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount"));
            String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));

            db.delete("transactions", "id=?", new String[]{String.valueOf(id)});
            cursor.close();
            db.close();

            return new Transaction(id, category, amount, timestamp);
        }

        if (cursor != null) cursor.close();
        db.close();
        return null;
    }
}
