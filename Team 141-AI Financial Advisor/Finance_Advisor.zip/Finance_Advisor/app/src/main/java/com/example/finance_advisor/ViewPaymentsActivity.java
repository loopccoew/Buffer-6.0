package com.example.finance_advisor;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewPaymentsActivity extends AppCompatActivity {

    RecyclerView paymentsRecyclerView;
    ArrayList<Payment> paymentsList;
    PaymentAdapter paymentAdapter;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_payments);

        paymentsRecyclerView = findViewById(R.id.paymentsRecyclerView);
        dbHelper = new DBHelper(this);
        paymentsList = dbHelper.getAllPayments(); // You should implement getAllPayments() in DBHelper

        paymentAdapter = new PaymentAdapter(this, paymentsList);
        paymentsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        paymentsRecyclerView.setAdapter(paymentAdapter);
    }
}
