package com.example.finance_advisor;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewHistoryActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private TransactionAdapter adapter;
    private ArrayList<Transaction> transactionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_history);

        recyclerView = findViewById(R.id.recyclerViewTransactions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Fetch transactions from DB
        DBHelper dbHelper = new DBHelper(this);
        transactionList = dbHelper.getAllTransactions();

        // Set adapter
        adapter = new TransactionAdapter(this, transactionList, dbHelper);
        recyclerView.setAdapter(adapter);
    }
}
