package com.example.finance_advisor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddTransactionActivity extends AppCompatActivity {

    private EditText editCategory, editAmount;
    private Button btnSaveTransaction;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        // Initialize views
        editCategory = findViewById(R.id.editCategory);
        editAmount = findViewById(R.id.editAmount);
        btnSaveTransaction = findViewById(R.id.btnSaveTransaction);
        dbHelper = new DBHelper(this);

        // Set up save button click listener
        btnSaveTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String category = editCategory.getText().toString();
                String amountStr = editAmount.getText().toString();

                if (category.isEmpty() || amountStr.isEmpty()) {
                    Toast.makeText(AddTransactionActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                double amount = Double.parseDouble(amountStr);

                // Insert the transaction into the database
                boolean isInserted = dbHelper.insertTransaction(category, amount, System.currentTimeMillis() + "");
                if (isInserted) {
                    Toast.makeText(AddTransactionActivity.this, "Transaction Added", Toast.LENGTH_SHORT).show();
                    finish(); // Close the activity and return to the previous screen
                } else {
                    Toast.makeText(AddTransactionActivity.this, "Failed to Add Transaction", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
