package com.example.finance_advisor;

public class User {
    private String name;
    private double income;
    private String profession;
    private String area;  // renamed from location

    // Constructor
    public User(String name, double income, String profession, String area) {
        this.name = name;
        this.income = income;
        this.profession = profession;
        this.area = area;
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getIncome() {
        return income;
    }

    public String getProfession() {
        return profession;
    }

    public String getArea() {  // renamed from getLocation()
        return area;
    }
}
