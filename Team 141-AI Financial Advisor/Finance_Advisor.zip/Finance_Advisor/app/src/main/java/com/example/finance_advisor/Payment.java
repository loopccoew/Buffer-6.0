package com.example.finance_advisor;

public class Payment {
    private int id;
    private String category;  // Change 'title' to 'category'
    private double amount;
    private String dueDate;

    public Payment(int id, String category, double amount, String dueDate) {
        this.id = id;
        this.category = category;  // Change 'title' to 'category'
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public int getId() {
        return id;
    }

    public String getCategory() {  // Change 'getTitle()' to 'getCategory()'
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public String getDueDate() {
        return dueDate;
    }
}
