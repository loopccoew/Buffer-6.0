package com.example.finance_advisor;

public class Transaction {
    private int id;
    private String category;
    private double amount;
    private String timestamp;

    // Constructor used when retrieving from DB (with ID and timestamp)
    public Transaction(int id, String category, double amount, String timestamp) {
        this.id = id;
        this.category = category;
        this.amount = amount;
        this.timestamp = timestamp;
    }

    // Constructor used when adding new transaction (no ID or timestamp yet)
    public Transaction(String category, double amount) {
        this.category = category;
        this.amount = amount;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public String getTimestamp() {
        return timestamp;
    }

    // Setters (optional if you plan to modify objects)
    public void setId(int id) {
        this.id = id;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    // Override toString() to display transaction details
    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", category='" + category + '\'' +
                ", amount=" + amount +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
}
