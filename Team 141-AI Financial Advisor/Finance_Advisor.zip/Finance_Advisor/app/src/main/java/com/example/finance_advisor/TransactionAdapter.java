package com.example.finance_advisor;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {
    private Context context;
    private List<Transaction> transactionList;
    private DBHelper dbHelper;

    public TransactionAdapter(Context context, List<Transaction> transactionList, DBHelper dbHelper) {
        this.context = context;
        this.transactionList = transactionList;
        this.dbHelper = dbHelper;
    }

    @Override
    public TransactionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TransactionViewHolder holder, int position) {
        Transaction transaction = transactionList.get(position);

        holder.categoryTextView.setText("Category: " + transaction.getCategory());
        holder.amountTextView.setText(String.format("Amount: ₹ %.2f", transaction.getAmount()));
        holder.timestampTextView.setText("Date: " + transaction.getTimestamp());

        // Edit
        holder.editButton.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditTransactionActivity.class);
            intent.putExtra("transaction_id", transaction.getId());
            context.startActivity(intent);
        });

        // Delete
        holder.deleteButton.setOnClickListener(v -> {
            deleteTransaction(transaction.getId(), position);
        });
    }

    @Override
    public int getItemCount() {
        return transactionList != null ? transactionList.size() : 0;
    }

    private void deleteTransaction(int transactionId, int position) {
        boolean success = dbHelper.deleteTransaction(transactionId);
        if (success) {
            transactionList.remove(position);
            notifyItemRemoved(position);
            Toast.makeText(context, "Transaction Deleted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Failed to Delete Transaction", Toast.LENGTH_SHORT).show();
        }
    }

    public static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView categoryTextView, amountTextView, timestampTextView;
        Button editButton, deleteButton;

        public TransactionViewHolder(View itemView) {
            super(itemView);
            categoryTextView = itemView.findViewById(R.id.textCategory);
            amountTextView = itemView.findViewById(R.id.textAmount);
            timestampTextView = itemView.findViewById(R.id.textTimestamp);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
