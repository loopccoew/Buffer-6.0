package com.example.finance_advisor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.PaymentViewHolder> {
    private Context context;
    private ArrayList<Payment> paymentList;

    public PaymentAdapter(Context context, ArrayList<Payment> paymentList) {
        this.context = context;
        this.paymentList = paymentList;
    }

    @Override
    public PaymentViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_payment, parent, false);
        return new PaymentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PaymentViewHolder holder, int position) {
        Payment payment = paymentList.get(position);
        // Use getCategory() instead of getTitle()
        holder.titleTextView.setText(payment.getCategory());
        holder.amountTextView.setText(String.format("₹ %.2f", payment.getAmount()));
        holder.dueDateTextView.setText(payment.getDueDate());
    }

    @Override
    public int getItemCount() {
        return paymentList.size();
    }

    public static class PaymentViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, amountTextView, dueDateTextView;

        public PaymentViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.textTitle);
            amountTextView = itemView.findViewById(R.id.textAmount);
            dueDateTextView = itemView.findViewById(R.id.textDueDate);
        }
    }
}
