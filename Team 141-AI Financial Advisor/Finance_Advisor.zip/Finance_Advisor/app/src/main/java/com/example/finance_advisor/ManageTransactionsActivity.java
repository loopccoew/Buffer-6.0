package com.example.finance_advisor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ManageTransactionsActivity extends AppCompatActivity {

    RecyclerView transactionsRecyclerView;
    ArrayList<Transaction> transactionList;
    TransactionAdapter transactionAdapter;
    DBHelper dbHelper;
    Button undoTransactionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_transactions);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        // Bind views
        transactionsRecyclerView = findViewById(R.id.transactionsRecyclerView);
        transactionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize Undo Button
        undoTransactionButton = findViewById(R.id.btnUndoTransaction); // Make sure this ID exists in XML

        // Set OnClickListener for Undo Button
        undoTransactionButton.setOnClickListener(v -> undoLastTransaction());

        // Load transaction list from database
        transactionList = dbHelper.getAllTransactions();
        transactionAdapter = new TransactionAdapter(this, transactionList, dbHelper);
        transactionsRecyclerView.setAdapter(transactionAdapter);
    }

    private void undoLastTransaction() {
        // Call the helper method to delete the last transaction
        boolean success = dbHelper.deleteLastTransaction();
        if (success) {
            Toast.makeText(this, "Last transaction undone", Toast.LENGTH_SHORT).show();

            // Refresh the transaction list and notify the adapter
            transactionList.clear();
            transactionList.addAll(dbHelper.getAllTransactions());
            transactionAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, "No transaction to undo", Toast.LENGTH_SHORT).show();
        }
    }

    // Example method to delete a transaction (you can hook this to a button or swipe)
    private void deleteTransaction(int id) {
        boolean success = dbHelper.deleteTransaction(id);
        if (success) {
            Toast.makeText(this, "Transaction Deleted", Toast.LENGTH_SHORT).show();
            // Refresh the transaction list after deleting
            transactionList = dbHelper.getAllTransactions();
            transactionAdapter = new TransactionAdapter(this, transactionList, dbHelper);
            transactionsRecyclerView.setAdapter(transactionAdapter);
        } else {
            Toast.makeText(this, "Error Deleting Transaction", Toast.LENGTH_SHORT).show();
        }
    }
}
