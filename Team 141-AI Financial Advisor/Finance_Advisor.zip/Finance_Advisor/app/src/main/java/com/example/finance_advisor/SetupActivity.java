package com.example.finance_advisor;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SetupActivity extends AppCompatActivity {

    private EditText editName, editIncome;
    private Spinner spinnerProfession;
    private RadioGroup radioArea;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);  // Ensure the correct XML layout file

        // Initialize views with the correct IDs
        editName = findViewById(R.id.editName);  // Make sure the ID is correct in the XML
        editIncome = findViewById(R.id.editIncome);  // Check the ID in XML
        spinnerProfession = findViewById(R.id.spinnerProfession);  // Check the ID in XML
        radioArea = findViewById(R.id.radioArea);  // Check the ID in XML
        btnSubmit = findViewById(R.id.btnSubmit);  // Check the ID in XML

        // Set up the profession spinner with options
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.professions, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProfession.setAdapter(adapter);

        // Button click event to save user data
        btnSubmit.setOnClickListener(view -> {
            String name = editName.getText().toString().trim();
            String incomeStr = editIncome.getText().toString().trim();

            if (name.isEmpty() || incomeStr.isEmpty()) {
                Toast.makeText(this, "Please enter both name and income.", Toast.LENGTH_SHORT).show();
                return;
            }

            double income = Double.parseDouble(incomeStr);

            // Get selected profession
            String profession = spinnerProfession.getSelectedItem().toString();

            // Get selected area (urban/rural)
            int selectedAreaId = radioArea.getCheckedRadioButtonId();
            String location = selectedAreaId == R.id.radioUrban ? "Urban" : "Rural";

            // Insert user data into database
            DBHelper dbHelper = new DBHelper(this);
            boolean isInserted = dbHelper.insertUser(name, income, profession, location);

            if (isInserted) {
                Toast.makeText(this, "User setup complete", Toast.LENGTH_SHORT).show();
                // Navigate to another screen (if required)
                // For example, startActivity(new Intent(SetupActivity.this, MainActivity.class));
            } else {
                Toast.makeText(this, "Error saving data. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
