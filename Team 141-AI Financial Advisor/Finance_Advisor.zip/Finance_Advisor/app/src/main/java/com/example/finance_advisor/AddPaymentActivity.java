package com.example.finance_advisor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddPaymentActivity extends AppCompatActivity {

    // Declare EditText and Button variables
    EditText paymentCategory, paymentAmount, paymentDueDate;
    Button savePaymentBtn;
    DBHelper dbHelper;  // Instance of DBHelper to interact with the database

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_payment);

        // Bind views from the layout XML
        paymentCategory = findViewById(R.id.paymentCategory);
        paymentAmount = findViewById(R.id.paymentAmount);
        paymentDueDate = findViewById(R.id.paymentDueDate);
        savePaymentBtn = findViewById(R.id.savePaymentBtn);

        // Initialize DBHelper for database interactions
        dbHelper = new DBHelper(this);

        // Set OnClickListener for the save button
        savePaymentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get values from input fields
                String category = paymentCategory.getText().toString();
                String amountStr = paymentAmount.getText().toString();
                String dueDate = paymentDueDate.getText().toString();

                // Validate input fields
                if (category.isEmpty() || amountStr.isEmpty() || dueDate.isEmpty()) {
                    Toast.makeText(AddPaymentActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Convert amount from String to double
                double amount = 0;
                try {
                    amount = Double.parseDouble(amountStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(AddPaymentActivity.this, "Invalid amount format", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save the payment to the database
                boolean isSaved = savePayment(category, amount, dueDate);

                // Display appropriate message based on whether the save was successful
                if (isSaved) {
                    Toast.makeText(AddPaymentActivity.this, "Payment Saved!", Toast.LENGTH_SHORT).show();
                    finish();  // Close the activity after saving
                } else {
                    Toast.makeText(AddPaymentActivity.this, "Failed to save payment", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to save the payment using DBHelper
    private boolean savePayment(String category, double amount, String dueDate) {
        // Attempt to insert the payment into the database using DBHelper's insertPayment method
        return dbHelper.insertPayment(category, amount, dueDate);
    }
}
