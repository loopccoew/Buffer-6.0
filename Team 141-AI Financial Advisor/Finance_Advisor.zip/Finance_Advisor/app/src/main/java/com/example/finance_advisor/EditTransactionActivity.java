package com.example.finance_advisor;

public class EditTransactionActivity {
}
