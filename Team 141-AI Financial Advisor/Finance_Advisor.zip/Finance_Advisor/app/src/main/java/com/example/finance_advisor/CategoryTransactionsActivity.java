package com.example.finance_advisor;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CategoryTransactionsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TransactionAdapter adapter;
    ArrayList<Transaction> transactionList;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_transactions);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);

        // Show dialog to input category
        showCategoryInputDialog();
    }

    private void showCategoryInputDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Category");

        View viewInflated = LayoutInflater.from(this).inflate(R.layout.dialog_input_category, null);
        final EditText input = viewInflated.findViewById(R.id.inputCategory);
        builder.setView(viewInflated);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String category = input.getText().toString().trim();
            if (!category.isEmpty()) {
                transactionList = dbHelper.getTransactionsByCategory(category);
                if (!transactionList.isEmpty()) {
                    adapter = new TransactionAdapter(CategoryTransactionsActivity.this, transactionList, dbHelper);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(this, "No transactions found for this category.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Category cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}
