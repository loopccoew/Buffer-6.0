package com.example.finance_advisor;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class ViewTransactionsActivity extends AppCompatActivity {

    private RecyclerView transactionsRecyclerView;
    private TransactionAdapter transactionAdapter;
    private ArrayList<Transaction> transactionList;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_transactions);

        transactionsRecyclerView = findViewById(R.id.transactionsRecyclerView);
        transactionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        transactionList = dbHelper.getAllTransactions();

        transactionAdapter = new TransactionAdapter(this, transactionList, dbHelper);
        transactionsRecyclerView.setAdapter(transactionAdapter);
    }
}
